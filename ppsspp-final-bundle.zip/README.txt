Upload each folder's files into the matching place in your repo (Add file > Upload files, then Commit):

1_Common_UI      -> Common/UI/                                   (3 files, replace)
2_Core           -> Core/                                        (2 files, replace)
3_UI             -> UI/                                          (16 files: 13 replace, 3 new)
4_icon           -> ios/assets.xcassets/AppIcon.appiconset/      (3 files, replace)
5_assets         -> assets/                                      (16 sounds: 7 replace, 9 new)
6_assets_themes  -> assets/themes/                               (2 new themes)

Then: Actions > Manual Generate iOS IPA/DEB > Run workflow.
